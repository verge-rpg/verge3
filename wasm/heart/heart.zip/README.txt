---------
<3 README
---------

Controls:
---------
ESC         Menu/Cancel
Enter       Confirm
Space Bar   Attack
S           Heal Spell
D           Nova Spell
F           Fire Spell
A           Ice Spell

Story:
------
There is an evil wizard trying to destroy the forest
with his evil magic!  You must go and save the forest!
Also, don't forget to get your girlfriend something
for Valentine's Day!

Authors:
--------

Hyptosis - Maps, Tiles, Sprites
Overkill - Code, Sounds
Ragecage - Magic Effects
TomT64 - Main Coder
Troupe - Music, Dialogue

